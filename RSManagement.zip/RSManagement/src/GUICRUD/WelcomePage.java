/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUICRUD;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WelcomePage extends JFrame {
    public WelcomePage() {
        setTitle("Welcome to Sistem Rumah Sakit");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel labelWelcome = new JLabel("Welcome to Sistem Rumah Sakit", JLabel.CENTER);
        labelWelcome.setFont(new Font("Arial", Font.BOLD, 22));
        add(labelWelcome, BorderLayout.CENTER);

        JButton btnNext = new JButton("Lanjut ke Login");
        add(btnNext, BorderLayout.SOUTH);

        btnNext.addActionListener(e -> {
            new LoginPage().setVisible(true);
            this.dispose();
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new WelcomePage().setVisible(true);
        });
    }
}

