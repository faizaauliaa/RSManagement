
package GUICRUD;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame {
    public Main() {
        setTitle("Sistem Manajemen Rumah Sakit");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 1, 10, 10));

        JButton btnPasien = new JButton("Manajemen Pasien");
        JButton btnDokter = new JButton("Manajemen Dokter");
        JButton btnObat = new JButton("Manajemen Obat");
        JButton btnKunjungan = new JButton("Manajemen Kunjungan");
        JButton btnRekamMedis = new JButton("Manajemen Rekam Medis");
        JButton btnPembayaran = new JButton("Manajemen Pembayaran");
        JButton btnResep = new JButton("Manajemen Resep");
        JButton btnDetailResep = new JButton("Manajemen Detail Resep");

        add(btnPasien);
        add(btnDokter);
        add(btnObat);
        add(btnKunjungan);
        add(btnRekamMedis);
        add(btnPembayaran);
        add(btnResep);
        add(btnDetailResep);

        btnPasien.addActionListener(e -> {
            PasienFrame pf = new PasienFrame();
            pf.setVisible(true);
        });
        
        btnDokter.addActionListener(e -> {
            DokterFrame dk = new DokterFrame();
            dk.setVisible(true);
        });

        btnObat.addActionListener(e -> {
            ObatFrame of = new ObatFrame();
            of.setVisible(true);
        });

        btnKunjungan.addActionListener(e -> {
            KunjunganFrame kf = new KunjunganFrame();
            kf.setVisible(true);
        });

        btnRekamMedis.addActionListener(e -> {
            RekamMedisFrame rmf = new RekamMedisFrame();
            rmf.setVisible(true);
        });

        btnPembayaran.addActionListener(e -> {
            PembayaranFrame pf = new PembayaranFrame();
            pf.setVisible(true);
        });

        btnResep.addActionListener(e -> {
            ResepFrame rf = new ResepFrame();
            rf.setVisible(true);
        });

        btnDetailResep.addActionListener(e -> {
            DetailResepFrame drf = new DetailResepFrame();
            drf.setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Main().setVisible(true);
        });
    }
}




