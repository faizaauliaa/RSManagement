package GUICRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KoneksiSQL {
    public static void main(String[] args) {
        Connection conn = null;
        try {
            String url = "jdbc:sqlserver://localhost:1433;databaseName=ProjectAkhir;encrypt=true;trustServerCertificate=true";
            String user = "Ninda";
            String password = "NindaSQL";

            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException e) {
            System.out.println("Koneksi gagal!");
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
