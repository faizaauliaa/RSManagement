package GUICRUD;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginPage extends JFrame {
    private JTextField txtNama;
    private JComboBox<String> comboRole;

    public LoginPage() {
        setTitle("Login Sistem Rumah Sakit");
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1, 10, 10));

        JPanel panelNama = new JPanel(new FlowLayout());
        panelNama.add(new JLabel("Masukkan Nama: "));
        txtNama = new JTextField(15);
        panelNama.add(txtNama);

        JButton btnLogin = new JButton("Login");

        add(panelNama);
        add(new JLabel());  
        add(btnLogin);

        btnLogin.addActionListener(e -> doLogin());
    }

    private void doLogin() {
        String nama = txtNama.getText().trim();

        if (nama.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, "Selamat datang, " + nama + "!");

        // Setelah login, buka MainApp atau modul sesuai role 
        Main main = new Main();
        main.setVisible(true);
        this.dispose();
    }
}

